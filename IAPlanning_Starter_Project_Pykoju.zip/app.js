
document.querySelector('.add-btn').addEventListener('click', () => {
    alert('Fonction Ajouter un événement bientôt disponible !');
});
